
#include <stdio.h>
#include <string.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "ch.h"
#include "chtime.h"
#include "hal.h"
#include "hal_pal.h"
#include "usbcfg.h"

/* 
   
   Information: 

   Denna fil innehåller 2 olika sätt att fixa periodiskt körande kod: 
     - Virtuella timers 
     - Thread 
    
   
*/ 

#define THREAD_WA_SIZE THD_WORKING_AREA_SIZE(2048)

static THD_FUNCTION(myThread, arg) {

  (void) arg; // Gör klart för Kompilatorn att vi vet om att vi ignorer arg.
  
  // Kör för alltid... 
  while (true) { 
    palTogglePad(GPIOD, 13);
    chThdSleepMilliseconds(1000); 
  }
}



// Timer Objekt. 
static virtual_timer_t timer0;

// "Callback" funktion. Anropas när timern når timeout
static void toggle_led(void* arg) {

  (void) arg; // Ignorera arg. 

  palTogglePad(GPIOD, 12);
  
  chSysLockFromISR();  // en funktion som anropas som callback har en
                       // slags ISR (interrupt service routine) status
                       // i ChibiOS. (Tolkar jag det som) 


  chVTSetI(&timer0, TIME_MS2I(500), toggle_led, NULL);
  // Det finns ofta "I" varianter av funktioner i ChibiOS som kan
  // användas från CALLBACKS.
  // Detta anrop (ovan) startar om timern och sätter en ny timeout
  // interval på 500MS.
  // TIME_MS2I(500) är ett macro som översätter 500ms till ett antal
  // ticks av en "systick-klocka"
  //  - Vadå systick-klocka?? 
  
  chSysUnlockFromISR();
  // Jag chansar att lock - unlock i stort sett stänger av och sätter på
  // interrupts.. Mer info behövs. 
}


int main(void) {
  
  // Det mesta i main är precis som i example0 koden. men ner mot slutet
  // av main startars timer och konfigureras led pinne. 
   
  halInit();
  chSysInit();

  sduObjectInit(&SDU1);
  sduStart(&SDU1, &serusbcfg);

  /*
   * Activates the USB driver and then the USB bus pull-up on D+.
   * Note, a delay is inserted in order to not have to disconnect the cable
   * after a reset.
   */
  usbDisconnectBus(serusbcfg.usbp);
  chThdSleepMilliseconds(1500);
  usbStart(serusbcfg.usbp, &usbcfg);
  usbConnectBus(serusbcfg.usbp);


  // sätt pin mode för LED på D12
  palSetPadMode(GPIOD, 12,
		PAL_MODE_OUTPUT_PUSHPULL );

  // sätt pin mode för LED på D13
  palSetPadMode(GPIOD, 13,
		PAL_MODE_OUTPUT_PUSHPULL );

  
  // initiera timer objekt
  chVTObjectInit(&timer0);
  // starta timer! 
  chVTSet(&timer0, TIME_MS2I(500), toggle_led, NULL);


  // Starta D13-blinkar tråd!
  thread_t *t = chThdCreateFromHeap(NULL,
				    THREAD_WA_SIZE,  // Arbetsyta, storlek.
				    "myThread",    
				    NORMALPRIO + 1, // högre prio än normalt
				    myThread,  // Tråd funktion
				    NULL); // passed as argument

  // retur värdet t är ignorerat här.
  // Vi vet ju att den kör "för evigt". Men om det hade varit en tråd som bara exekverade en kort stund
  // och sedan "stänger ner sig" så kan man tex vänta på detta med
  // chThdWait(t);
  
  
	
  /*
   *  Main thread activity...
   */
  while (true) {
    // Gör ingenting loop ;) 
    chThdSleepMilliseconds(1000);
  }
}
