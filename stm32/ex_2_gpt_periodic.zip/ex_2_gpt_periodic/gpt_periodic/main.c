
#include <stdio.h>
#include <string.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "ch.h"
#include "chtime.h"
#include "hal.h"
#include "hal_pal.h"
#include "usbcfg.h"

/* 
   
   Information:

   Ändra i halconf.h 
   #define HAL_USE_GPT TRUE

   Ämdra i mcuconf.h
  
   
*/ 

void toggler(GPTDriver *arg) {

  (void) arg;
  
  palTogglePad(GPIOD, 12);
  palTogglePad(GPIOA, 0);
}


GPTConfig gpt_config = {
  1000000,
  toggler,
  TIM_CR2_MMS_1, // What ??? 
  0
};

int main(void) {

  halInit();
  chSysInit();

  sduObjectInit(&SDU1);
  sduStart(&SDU1, &serusbcfg);

  /*
   * Activates the USB driver and then the USB bus pull-up on D+.
   * Note, a delay is inserted in order to not have to disconnect the cable
   * after a reset.
   */
  usbDisconnectBus(serusbcfg.usbp);
  chThdSleepMilliseconds(1500);
  usbStart(serusbcfg.usbp, &usbcfg);
  usbConnectBus(serusbcfg.usbp);


  // sätt pin mode för LED på D12
  palSetPadMode(GPIOD, 12,
		PAL_MODE_OUTPUT_PUSHPULL );
  palSetPadMode(GPIOA, 0,
		PAL_MODE_OUTPUT_PUSHPULL );

  gptObjectInit(&GPTD1);

  gptStart(&GPTD1, &gpt_config);

  gptStartContinuous(&GPTD1, 4);
  
  /*
   *  Main thread activity...
   */
  while (true) {
    // Gör ingenting loop ;) 
    chThdSleepMilliseconds(1000);
  }
}
