
#include <stdio.h>
#include <string.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>

#include "ch.h"
#include "chtime.h"
#include "hal.h"
#include "hal_pal.h"
#include "hal_dac.h"
#include "usbcfg.h"

unsigned short sin_buffer[256]; 

unsigned int freq = 1000;
unsigned int base_freq = 96000;
float base_freq_period = 1.0/96000.0;


void toggler(GPTDriver *arg) {
  (void) arg;

  static unsigned int cnt = 0; 
 
  float t = ((float)cnt * base_freq_period);
  unsigned char a = (unsigned char)(t * 256 * freq);
  
  dacPutChannelX(&DACD1, 0, sin_buffer[a]);
  palTogglePad(GPIOD, 12);
  palTogglePad(GPIOA, 0);
  
  cnt++;
}


GPTConfig gpt_config = {
  192000,  //96000,
  toggler,
  TIM_CR2_MMS_1, // What ??? 
  0
};

DACConfig dac_config = {
  1, 
  DAC_DHRM_12BIT_RIGHT,
  0 
};


int main(void) {

  halInit();
  chSysInit();

  for (int i = 0; i < 256; i ++) {
    sin_buffer[i] = (unsigned short)(2047.5 + (2047.5 * sin(2*3.1459*((float)i/256.0))));
  }

  sduObjectInit(&SDU1);
  sduStart(&SDU1, &serusbcfg);

  /*
   * Activates the USB driver and then the USB bus pull-up on D+.
   * Note, a delay is inserted in order to not have to disconnect the cable
   * after a reset.
   */
  usbDisconnectBus(serusbcfg.usbp);
  chThdSleepMilliseconds(1500);
  usbStart(serusbcfg.usbp, &usbcfg);
  usbConnectBus(serusbcfg.usbp);


  // sätt pin mode för LED på D12
  palSetPadMode(GPIOD, 12,
		PAL_MODE_OUTPUT_PUSHPULL );
  palSetPadMode(GPIOA, 0,
		PAL_MODE_OUTPUT_PUSHPULL );

  palSetPadMode(GPIOA, 4,
		PAL_MODE_INPUT_ANALOG);

  dacStart(&DACD1, &dac_config);

  gptObjectInit(&GPTD1);

  gptStart(&GPTD1, &gpt_config);

  gptStartContinuous(&GPTD1, 2);

  
  
  /*
   *  Main thread activity...
   */
  while (true) {
    // Gör ingenting loop ;) 
    chThdSleepMilliseconds(1000);
  }
}
