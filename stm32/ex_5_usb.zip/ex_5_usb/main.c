/*
    Andreas first NCO (based on Joel's "example0")
		v0: 2019-08-23, Project created
*/

#include <stdio.h>
#include <string.h>
//#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "ch.h"
#include "hal.h"
#include "usbcfg.h"
#include "lut.h" //Include wawetables

int main(void) {
	halInit();
	chSysInit();

	sduObjectInit(&SDU1);
	sduStart(&SDU1, &serusbcfg);

	/*
	 * Activates the USB driver and then the USB bus pull-up on D+.
	 * Note, a delay is inserted in order to not have to disconnect the cable
	 * after a reset.
	 */
	usbDisconnectBus(serusbcfg.usbp);
	chThdSleepMilliseconds(1500);
	usbStart(serusbcfg.usbp, &usbcfg);
	usbConnectBus(serusbcfg.usbp);

	palSetPadMode(GPIOD, 13, PAL_MODE_OUTPUT_PUSHPULL);
 
	/*
	 *  Main thread activity...
	 *  snprintf(); //Can be used to convert e.g. %f to string
	 */
	while (true) {
	  palTogglePad(GPIOD, 13);
	  chThdSleepMilliseconds(500);
	  chprintf((BaseSequentialStream *)&SDU1, "%s", "TEST");
	}
}
