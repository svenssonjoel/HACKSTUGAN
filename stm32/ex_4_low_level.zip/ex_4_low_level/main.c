
#include <stdio.h>
#include <string.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "ch.h"
#include "hal.h"
#include "usbcfg.h"
 
#define P_BASE 0x40000000U                // PERIPHERALS BASE ADDRESS 

#define GPIO_A    (P_BASE + 0x00020000U)
#define GPIO_B    (P_BASE + 0x00020400U)
#define GPIO_C    (P_BASE + 0x00020800U)
#define GPIO_D    (P_BASE + 0x00020C00U)

#define RCC_BASE  (P_BASE + 0x23800U)     // RESET AND CLOCK CONTROL REGISTER
#define RCC_CENR  (RCC_BASE + 0x30)       // CLOCK ENABLE REGISTER 

#define MODER(X)         ((X) + 0x0U)     // MODE REGISTER
#define OTYPER(X)        ((X) + 0x04U)    // OUTPUT TYPE REGISTER
#define OSPEEDR(X)       ((X) + 0x08U)    // OUTPUT SPEED REGISTER 
#define PUPDR(X)         ((X) + 0x0CU)    // PULL-UP/DOWN REGISTER
#define IDR(X)           ((X) + 0x10U)    // INPUT DATA REGISTER 
#define ODR(X)           ((X) + 0x14U)    // OUTPUT DATA REGISTER
#define BSRR(X)          ((X) + 0x18U)    // BIT SET/RESET REGISTER


// MAYBE MAKE THESE ENUM? 
#define INPUT_MODE     0
#define OUTPUT_MODE    1
#define ALTERNATE_MODE 2
#define ANALOG_MODE    3

#define LOW_SPEED         0
#define MEDIUM_SPEED      1
#define HIGH_SPEED        2
#define VERY_HIGH_SPEED   3 

#define NO_PULLPUSH 0
#define PULL_UP     1
#define PUSH_DOWN   2


inline void set_bit(uint32_t register_addr, uint32_t bit_pos, bool set) {

  unsigned int *reg = (unsigned int *)register_addr;
  
  if (set) { 
    *reg = *reg | (1 << bit_pos);
  } else {
    *reg = *reg & ~(1 << bit_pos);
  }
}

void enable_gpio_d() {
  set_bit(RCC_CENR, 3, true); // Bit three in this register enbles clock for GPIO_D
}


void set_moder(uint32_t register_offset, uint32_t pin, uint32_t mode) {

  uint32_t reg = MODER(register_offset);
  
  uint32_t bp0 = 2* pin;
  uint32_t bp1 = bp0+1;
  
  switch (mode) {
  case INPUT_MODE:
    set_bit(reg, bp0, false);
    set_bit(reg, bp1, false); 
    break;
  case OUTPUT_MODE:
    set_bit(reg, bp0, true);
    set_bit(reg, bp1, false);
    break;
  case ALTERNATE_MODE:
    set_bit(reg, bp0, false);
    set_bit(reg, bp1, true);
    break;
  case ANALOG_MODE:
    set_bit(reg, bp0, true);
    set_bit(reg, bp1, true);
    break;
  }
  //if not a proper mode, just ignore... 
}

void set_speed(uint32_t register_offset, uint32_t pin, uint32_t speed) {

  uint32_t reg = OSPEEDR(register_offset);
  
  uint32_t bp0 = 2*pin;
  uint32_t bp1 = bp0+1;

  switch(speed) {
  case LOW_SPEED:
    set_bit(reg,bp0,false);
    set_bit(reg,bp1,false);
    break;
  case MEDIUM_SPEED:
    set_bit(reg,bp0,true);
    set_bit(reg,bp1,false);
    break;
  case HIGH_SPEED:
    set_bit(reg,bp0,false);
    set_bit(reg,bp1,true);
    break;
  case VERY_HIGH_SPEED:
    set_bit(reg,bp0,true);
    set_bit(reg,bp1,true);
    break;
  }
}

void set_pupd(uint32_t register_offset, uint32_t pin, uint32_t pupd) {

  uint32_t reg = PUPDR(register_offset);
  
  uint32_t bp0 = 2*pin;
  uint32_t bp1 = bp0+1;

  switch(pupd) {
  case NO_PULLPUSH:
    set_bit(reg,bp0,false);
    set_bit(reg,bp1,false);
    break;
  case PULL_UP:
    set_bit(reg,bp0,true);
    set_bit(reg,bp1,false);
    break;
  case PUSH_DOWN:
    set_bit(reg,bp0,false);
    set_bit(reg,bp1,true);
    break;
  }
}


#define THREAD_WA_SIZE THD_WORKING_AREA_SIZE(2048)

static THD_FUNCTION(myThread, arg) {

  bool pin_state = false; 
  
  (void) arg; // Gör klart för Kompilatorn att vi vet om att vi ignorer arg.
  
  // Kör för alltid... 
  while (true) {

    set_bit( ODR(GPIO_D), 13, pin_state); 
    pin_state = !pin_state;
    //palTogglePad(GPIOD, 13);
    chThdSleepMilliseconds(50); 
  }
}

int main(void) {
    
  halInit();
  chSysInit();

  sduObjectInit(&SDU1);
  sduStart(&SDU1, &serusbcfg);

  /*
   * Activates the USB driver and then the USB bus pull-up on D+.
   * Note, a delay is inserted in order to not have to disconnect the cable
   * after a reset.
   */
  usbDisconnectBus(serusbcfg.usbp);
  chThdSleepMilliseconds(1500);
  usbStart(serusbcfg.usbp, &usbcfg);
  usbConnectBus(serusbcfg.usbp);


  // sätt pin mode för LED på D13
  //palSetPadMode(GPIOD, 13,
  //	       	  PAL_MODE_OUTPUT_PUSHPULL);
  
  set_moder(GPIO_D, 13, OUTPUT_MODE);
  set_speed(GPIO_D, 13, LOW_SPEED);
  set_pupd(GPIO_D, 13, PULL_UP);
  
  
  // Starta D13-blinkar tråd!
  thread_t *t = chThdCreateFromHeap(NULL,
				    THREAD_WA_SIZE,  // Arbetsyta, storlek.
				    "myThread",    
				    NORMALPRIO + 1, // högre prio än normalt
				    myThread,  // Tråd funktion
				    NULL); // passed as argument
  
  /*
   *  Main thread activity...
   */
  while (true) {
    // Gör ingenting loop ;) 
    chThdSleepMilliseconds(1000);
  }
}
