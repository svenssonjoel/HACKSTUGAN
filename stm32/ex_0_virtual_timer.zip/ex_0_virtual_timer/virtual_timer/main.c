
#include <stdio.h>
#include <string.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "ch.h"
#include "chtime.h"
#include "hal.h"
#include "hal_pal.h"
#include "usbcfg.h"

/* 
   
   Information:

   Det verkar som att det i många fall inte är direkt nödvändigt att
   sätta upp interrupts när man jobbar med ChibiOS. Tanken verkar vara
   att man använder något som heter "virtuella timers" (som kanske i
   sin tur är implementerade via timer baserade interrupts) eller att
   man använder en tråd som är dedikerad till den "periodiska"
   uppgiften.  

   Denna exempelfil blinkar en LED m.h.a en virtuell timer. 
   
   
*/ 


// Timer Objekt. 
static virtual_timer_t timer0;



// "Callback" funktion. Anropas när timern når timeout
static void toggle_led(void* arg) {

  (void) arg; // Ignorera arg. 

  palTogglePad(GPIOD, 12);
  
  chSysLockFromISR();  // en funktion som anropas som callback har en
                       // slags ISR (interrupt service routine) status
                       // i ChibiOS. (Tolkar jag det som) 


  chVTSetI(&timer0, TIME_MS2I(500), toggle_led, NULL);
  // Det finns ofta "I" varianter av funktioner i ChibiOS som kan
  // användas från CALLBACKS.
  // Detta anrop (ovan) startar om timern och sätter en ny timeout
  // interval på 500MS.
  // TIME_MS2I(500) är ett macro som översätter 500ms till ett antal
  // ticks av en "systick-klocka"
  //  - Vadå systick-klocka?? 
  
  chSysUnlockFromISR();
  // Jag chansar att lock - unlock i stort sett stänger av och sätter på
  // interrupts.. Mer info behövs. 
}


int main(void) {
  
  // Det mesta i main är precis som i example0 koden. men ner mot slutet
  // av main startars timer och konfigureras led pinne. 
   
  halInit();
  chSysInit();

  sduObjectInit(&SDU1);
  sduStart(&SDU1, &serusbcfg);

  /*
   * Activates the USB driver and then the USB bus pull-up on D+.
   * Note, a delay is inserted in order to not have to disconnect the cable
   * after a reset.
   */
  usbDisconnectBus(serusbcfg.usbp);
  chThdSleepMilliseconds(1500);
  usbStart(serusbcfg.usbp, &usbcfg);
  usbConnectBus(serusbcfg.usbp);


  // sätt pin mode för LED på D12
  palSetPadMode(GPIOD, 12,
		PAL_MODE_OUTPUT_PUSHPULL );

  // initiera timer objekt
  chVTObjectInit(&timer0);
  // starta timer! 
  chVTSet(&timer0, TIME_MS2I(500), toggle_led, NULL);
	
  /*
   *  Main thread activity...
   */
  while (true) {
    // Gör ingenting loop ;) 
    chThdSleepMilliseconds(1000);
  }
}
